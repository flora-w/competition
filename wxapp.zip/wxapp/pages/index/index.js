// pages/index/index.js
var util = require('../../utils/util.js');
var api = require('../../config/api.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    site:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      site: app.globalData.site
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  NotSupported: function () {
    wx.showModal({
    //  title: '错误信息',
      content: '暂不支持此操作',
      showCancel: false
    });
  },
  QueryResign: function () {
    let that = this;
    wx.showLoading({
      title:  '加载中',
    }) 
    util.request(api.ResignDetail, { empno: app.globalData.userInfo }).then(function (res) {
      if (res.result == "success") {
        wx.hideLoading(); 
        wx.navigateTo({
          url: '/pages/resign/resign',
        })

      } else {
        wx.hideLoading(); 
        wx.showModal({
          content: '暂无离职信息',
          showCancel: false
        });
      }
    });
  },
  // adddetial: function () {
  //   wx.navigateTo({
  //     url: '../smartService/smartService'
  //   })
  // },
   
})