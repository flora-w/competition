var api = require('../../config/api.js');
var app = getApp();
const { $Toast } = require('../../components/base/index');
var { $Message } = require('../../components/base/index');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    empno: '', //工号
    password: '', //密码
    identity:true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.hideTabBar();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearInterval(this.timer)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    // 显示顶部刷新图标
    wx.showNavigationBarLoading();
    // 增加下拉刷新数据的功能
    var self = this;
    //this.getGoodsList();
    // 隐藏导航栏加载框
    wx.hideNavigationBarLoading();
    // 停止下拉动作
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
  * 自定义函数
  */
  //键盘输入获取工号
  getEmpno(e) {
    let temp = e.detail.value;
    this.setData({
      empno: temp
    })
    app.globalData.userInfo = temp;
  },
  //键盘事件输入密码
  getPassword(e) {
    this.setData({
      password: e.detail.value
    })
  },
  //切换身份
  swicthIdentity: function () {
    this.setData({
      identity: !this.data.identity,
      empno:'',
      password:''
    })
  },
  //登陆
  login() {
    if(this.data.identity){
      this.empnoLogin();
    }
    else{
      this.otherLogin()
    }
  },
  //员工登陆
  empnoLogin: function() {
    if (this.data.empno && this.data.password) {
		wx.showLoading({
			title: '登入中',
		}) 
      wx.request({
        url: api.Login,
        method: 'POST',
        data: {
          EmpNo: this.data.empno,
          Password: this.data.password
        },
        dataType: 'json',
        success(res) {   
          if (res.data.Code == 2) { 
           wx.setStorage({
              key: 'token',
              data: res.data.Token,
            })
          /*  wx.setStorage({
              key: 'userInfo',
              data: res.data.AccountID,
            })*/
            app.globalData.userInfo = res.data.AccountID;
			      wx.hideLoading(); 
            wx.navigateTo({
              url: '/pages/changepwd/changepwd',
            })
          }
          else if (res.data.Code == 1){
            wx.setStorage({
              key: 'token',
              data: res.data.Token,
            })
            app.globalData.userInfo = res.data.AccountID;
            app.globalData.site = res.data.site;
            app.globalData.chname = res.data.chname;
            app.globalData.dept = res.data.dept;
            app.globalData.position = res.data.position;
            app.globalData.company = res.data.company;
			      wx.hideLoading(); 
            wx.navigateTo({
              url: '/pages/index/index',
            }) 
            // wx.switchTab({
            //   url: '/pages/tabwork/tabwork',
            // })
          } 
          else if (res.data.Code == 0) {
            wx.hideLoading(); 
            // wx.showToast({
            //   title: res.data.Message,
            //   image: '../../static/image/err.png'
            // })
            $Toast({
              content: res.data.Message,
              type: 'error'
            });
          } else {
			      wx.hideLoading(); 
            wx.showToast({
              title: res.data.Message,
              icon: "none"
            })
          }
        },
      })

    } else {
      wx.showToast({
        image: '../../static/image/err.png',
        title: '请填写完整！',
      })
    }
  },
  //其他登陆
  otherLogin:function (){
    if (this.data.empno && this.data.password ){
      wx.showLoading({
        title:  '登入中',
      }) 
      wx.request({
        url: api.VisitorsLogin,
        method:'POST',
        data: {
          EmpNo: this.data.empno,
          Password: this.data.password
        },
        dataType: 'json',
        success:(res) => {
          if(res.data.code == 1){
            app.globalData.site = res.data.site;
            wx.hideLoading();
            this.handleDefault('登入成功','success')
            wx.navigateTo({
              url: '/pages/otherIndex/index',
            })
          }
          else{
            wx.hideLoading(); 
            this.handleDefault(res.data.message,'error')
          }
        }
      })
    }
    else{
      this.handleDefault('请填写完整','warning')
      wx.hideLoading();  
    }
  },
  handleDefault: function (content='出现错误',type='warning',duration=3) {
    $Message({
      content,
      type,
      duration
    });
  },
})