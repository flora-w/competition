﻿// pages/questionCollection/questionCollection.js

const app = getApp();
var inputVal = '';
// var userid = app.globalData.userInfo;


// // var userid = 'K18070201';
// console.log('工號：'+userid);
// var userchname = app.globalData.chname;
// var userchname = '辛蕊';
// var userInfo = app.globalData.userInfo;
// console.log('userid:'+userInfo);
// var userchname = '';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputVal : '',
    answer : '',
    userInfo: '',
    userchname: '',
    show:false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData:['宿舍','餐厅','卫生','交通车','安管中心','厂务','薪资福利','纬隆餐厅','其他'],//下拉列表的数据
    index:0,//选择的下拉列表下标
    riderCommentList: [{
      value: '公共事务课',
      selected: false ,
      title: '公共事务课'
    },{
      value: '公共服务课',
      selected: false ,
      title: '公共服务课'
    },{
      value: '公共卫生课',
      selected: false ,
      title: '公共卫生课'
    },{
      value: '安管中心',
      selected: false ,
      title: '安管中心'
    },{
      value: '员工关系部',
      selected: false ,
      title: '员工关系部'
    },{
      value: '薪资管理部',
      selected: false ,
      title: '薪资管理部'
    }]
  },
  checkboxChange(e){
    console.log('checkboxChange e:',e);
    let string = "riderCommentList["+e.target.dataset.index+"].selected"
        this.setData({
            [string]: !this.data.riderCommentList[e.target.dataset.index].selected
        })
        let detailValue = this.data.riderCommentList.filter(it => it.selected).map(it => it.value)
        console.log('所有选中的值为：', detailValue)
  },
  // checkboxChange: function (e) {
  //   console.log('checkbox发生change事件，携带value值为：', e.detail.value)
  // },
  // 点击下拉显示框
  selectTap(){
    this.setData({
      show: !this.data.show
    });
  },
  // 点击下拉列表
  optionTap(e){
    let Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.setData({
      index:Index,
      show:!this.data.show
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.setData({
      userInfo: app.globalData.userInfo,
      userchname: app.globalData.userchname
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

    this.setData({
      userid: localdata.testJSONList
    });

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  mySelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      tihuoWay: name,
      select: false
    })
  },
})