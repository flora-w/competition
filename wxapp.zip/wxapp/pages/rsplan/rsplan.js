// pages/rsplan/rsplan.js
var util = require('../../utils/util.js');
var api = require('../../config/api.js');
var app = getApp();
const { $Toast } = require('../../components/base/index');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    current: 'location',
    nowdate:"",
    flag:"",
    resultL:"none",
    resultO:"none",
    DateList: [],
    LocationDetailList:[],
    OutsideDetailList: [],
  },
  //菜单切换
  handleChange({ detail }) {
    this.setData({
      current: detail.key
    });
    if (detail.key == 'location') {
      if (this.data.resultL=="none"){
        $Toast({
          content: '無開餐信息',
          type: 'warning'
        });
      }
    }
    else if (detail.key == 'outside') {
      if (this.data.resultO == "none") {
        $Toast({
          content: '無開餐信息',
          type: 'warning'
        });
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (app.globalData.userInfo == "") {
      wx.showModal({
        title: '',
        content: '请先登入',
        success: function (res) {
          if (res.confirm) {
            wx.removeStorageSync("userInfo");
            wx.removeStorageSync("token");

            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
    else {
      wx.showLoading({
        title: '加载中...',
        success: function () {
        }
      });
      this.getData();
    } 
  },
  getData() {
    let that = this;
    //util.request(api.RsPlan, { empno: app.globalData.userInfo, site: app.globalData.site })
    util.request(api.RsPlan, { empno: 'K17058197', site: 'WKS' })
      .then(function (res) {
        if (res.resultL == "success") {
          that.setData({
            resultL: res.resultL,
            LocationDetailList: that.data.LocationDetailList.concat(res.LocationDetailList),
          });
        }
        if (res.resultO == "success"){
          that.setData({
            resultO: res.resultO,
            OutsideDetailList: that.data.OutsideDetailList.concat(res.OutsideDetailList),
          });
        }
        let width;
        if (res.nowDate == res.DateList[0].Monday){
          width="370%";
        }
        else if (res.nowDate == res.DateList[0].Tuesday)
        {
          width = "325%";
        }
        else if (res.nowDate == res.DateList[0].Wednesday) {
          width = "280%";
        }
        else if (res.nowDate == res.DateList[0].Thursday) {
          width = "235%";
        }
        else if (res.nowDate == res.DateList[0].Friday) {
          width = "190%";
        }
        else if (res.nowDate == res.DateList[0].Saturday) {
          width = "145%";
        }
        else if (res.nowDate == res.DateList[0].Sunday) {
          width = "100%";
        }
        that.setData({
          nowdate:res.nowDate,
          DateList: that.data.DateList.concat(res.DateList),
          flag: width,
        });
      });
      wx.hideLoading();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})