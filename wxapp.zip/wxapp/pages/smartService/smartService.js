  //监听input获得焦点

  var util = require('../../utils/util.js');
  var api = require('../../config/api.js');
  const app = getApp(); 
  var inputVal = '';
  var msgList = [];
  //獲取屏幕寬高
  var windowWidth = wx.getSystemInfoSync().windowWidth;
  var windowHeight = wx.getSystemInfoSync().windowHeight;
  var keyHeight = 0;
  
  /**
   * 初始化数据
   */
  function initData(that) {
    //定義頁面加載時就要顯示的數據
    inputVal = '';
    util.request(api.smartService0, { uid: app.globalData.userInfo, timestamp: Date.parse(new Date())})
    .then(function (res) {
      console.log('當前時間戳0---' + that.data.timestamp);
      console.log('首回复0---' + res.text);
      console.log('首回复顯示0---' + res.result);
      console.log('選擇0---' + res.option);
      if (res.option.indexOf('[]')==0 || res.option == "[]") {
        that.setData({
          content: res.text,
          option: []
        })
      }
      else {
        that.setData({
          content: res.text,
          option: res.option.substring(2, res.option.indexOf('"]')).split('","')
        })
      }
      console.log("text:"+res.text);
      msgList.push({
        speaker: 'server',
        contentType: 'text',
        // answer: that.data.text,
        // 必須用this.data數據才會拿到
        content: res.text,
        option: that.data.option
      })
      that.setData({
        msgList,
      })
    })  
}

function getBaseData(that) {
  util.request(api.smartService1, { uid: app.globalData.userInfo, timestamp: Date.parse(new Date())})
        .then(function (res) {
          console.log('當前時間戳1---' + that.data.timestamp);
          console.log('首回复顯示1---' + res.result);
          console.log('首回复顯示1---' + res.message);
        })
}

Page({
    /**
     * 页面的初始数据
     */
    data: {
      msgList: [],
      inputVal: '',
      // data: '',
      timestamp: 0,
      // toView: '',
      option: '',
      scrollHeight: '91vh',
      inputBottom: 0
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      wx.getUserInfo({
        success: function(res) {
          if (res.authSetting['scope.userInfo']) {
            // 已经授权，可以直接调用 getUserInfo 获取头像昵称
            wx.getUserInfo({
              success: function (res) {
                console.log(res.userInfo)
              }
            })
          }
        }
      })

      //Date.parse得到的數據單位是毫秒，new Date()得到的數據單位是秒
      var timestamp = Date.parse(new Date());
      console.log("当前时间戳为：" + timestamp);
      //initData是初始數據函數
      initData(this);
      getBaseData(this);
    },

    sendClick: function (e) {
      // this.data.LabelNew = e.detail.value;
      this.data.sendClick = e.detail.value;
    },
    send(e) {
      let that = this;  
      if (this.data.sendClick != '') {
        e.detail.value = this.data.sendClick;
      msgList.push({
        speaker: 'customer',
        contentType: 'text',
        content: e.detail.value
      })
      that.setData({
        msgList,
        inputVal,
        data: e.detail.value,
  
      });
      that.setData({
        toView: 'msg-'+(msgList.length - 1)
      });
      console.log('輸入的數據是：' + e.detail.value);

      util.request(api.smartService, { uid: app.globalData.userInfo, timestamp: Date.parse(new Date()), speak: that.data.data })
        .then(function (res) {
          console.log('輸入內容為：' + that.data.data);
          console.log('當前時間戳---' + that.data.timestamp);
          console.log('首回复---' + res.text);
          console.log('首回复顯示---' + res.result);
          console.log('選擇---' + res.option);
          console.log('send=action---' + res.action);
          if (res.option.indexOf('[]')==0 || res.option == "[]") {
            that.setData({
              content: res.text,
              option: []
            })
          }
          else {
            console.log(res.option.indexOf('"]'))
            console.log(res.option.substring(2, res.option.indexOf('"]')))
            that.setData({
              content: res.text,
              option: res.option.substring(2, res.option.indexOf('"]')).split('","')
            })
          }
          if (res.action.indexOf('fb_button')!=-1){
            that.setData({
              action: "fb_button",
            })
          }else{
            that.setData({
              action: [],
            })
          }
          console.log('改後的action'+that.data.action);

          msgList.push({
            speaker: 'server',
            contentType: 'text',
            // answer: that.data.text,
            //必須用this.data數據才會拿到
            content: that.data.content,
            option: that.data.option,
            action: that.data.action
          })
          that.setData({
            msgList,
            // toView: 'msg-' + (msgList.length - 1)
          })
          that.setData({
            toView: 'msg-'+(msgList.length - 1)
          });
        })
      console.log('數組長度：' + msgList.length);
      }

   


    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 获取聚焦
     */
    focus: function (e) {
      keyHeight = e.detail.height;
      // keyHeight = '70px';
      console.log('key:'+keyHeight);
      this.setData({
        scrollHeight: (windowHeight - keyHeight) + 'px',
      });
      this.setData({
        toView: 'msg-' + (msgList.length - 1),
        inputBottom: keyHeight + 'px'
      })
      //计算msg高度
      // calScrollHeight(this, keyHeight);
    },

    //失去聚焦(软键盘消失)
    blur: function (e) {
      this.setData({
        scrollHeight: '91vh',
        inputBottom: 0
      })
      this.setData({
        toView: 'msg-' + (msgList.length - 1)
      })
    },
    

/* 點擊option使其內容傳輸到input裡 */
    changeValueClick : function(e){
      let that = this;
      var value = e.target.dataset.text;
      console.log(value);
      msgList.push({
        speaker: 'customer',
        contentType: 'text',
        content: value
      });
      that.setData({
        inputVal,
        msgList
      });
      var newcontent = '';
      var newoption = [];
    
      util.request(api.smartService, { uid: app.globalData.userInfo, timestamp: Date.parse(new Date()), speak: value })
        .then(function (res) {
          console.log('輸入內容為：' + value);
          console.log('首回复---' + res.text);
          console.log('首回复顯示---' + res.result);
          console.log('選擇---' + res.option);
          console.log('click=action---'+res.action);
          if (res.option.indexOf('[]')==0 || res.option == "[]") {
            newcontent = res.text;
          }
          else {
            console.log(res.option.indexOf('"]'))
            console.log(res.option.substring(2, res.option.indexOf('"]')))
            newcontent = res.text,
              newoption = res.option.substring(2, res.option.indexOf('"]')).split('","')
          }
          if (res.action.indexOf('fb_button')!=-1){
            that.setData({
              action: "fb_button",
            })
          }else{
            that.setData({
              action: [],
            })
          }
       
          msgList.push({
            speaker: 'server',
            contentType: 'text',
            // answer: that.data.text,
            //必須用this.data數據才會拿到
            content: newcontent,
            option: newoption,
            action: that.data.action
          })
          that.setData({
            msgList,
          })
          that.setData({
            toView: 'msg-'+(msgList.length - 1)
          });
        })
        console.log(that.data.msgList);
      },

      clickNo: function(e){
        let that = this;
        var value = e.currentTarget.dataset.text;
        console.log(value);
        msgList.push({
          speaker: 'customer',
          contentType: 'text',
          content: value
        });
        that.setData({
          inputVal,
          msgList
        });
        var newcontent = '';
        var newoption = [];
  
        util.request(api.smartService, { uid: app.globalData.userInfo, timestamp: Date.parse(new Date()), speak: 'n' })
          .then(function (res) {
            console.log('輸入內容為：' + value);
            console.log('首回复---' + res.text);
            console.log('首回复顯示---' + res.result);
            console.log('選擇---' + res.option);
            console.log('click=action---'+res.action);
            if (res.option.indexOf('[]')==0 || res.option == "[]") {
              newcontent = res.text;
            }
            else {
              console.log(res.option.indexOf('"]'))
              console.log(res.option.substring(2, res.option.indexOf('"]')))
              newcontent = res.text,
                newoption = res.option.substring(2, res.option.indexOf('"]')).split('","')
            }
            if (res.action.indexOf('fb_button')!=-1){
              that.setData({
                action: "fb_button",
              })
            }else{
              that.setData({
                action: [],
              })
            }
            msgList.push({
              speaker: 'server',
              contentType: 'text',
              // answer: that.data.text,
              //必須用this.data數據才會拿到
              content: newcontent,
              option: newoption,
              action: that.data.action
            })
            that.setData({
              msgList,
            })
            that.setData({
              toView: 'msg-'+(msgList.length - 1)
            });
          })
          console.log(that.data.msgList);
      },
      clickYes: function(e){
        let that = this;
        var value = e.currentTarget.dataset.text;
        console.log(value);
        msgList.push({
          speaker: 'customer',
          contentType: 'text',
          content: value
        });
        that.setData({
          inputVal,
          msgList
        });
        var newcontent = '';
        var newoption = [];
        util.request(api.smartService, { uid: app.globalData.userInfo, timestamp: Date.parse(new Date()), speak: 'y' })
          .then(function (res) {
            console.log('輸入內容為：' + value);
            console.log('首回复---' + res.text);
            console.log('首回复顯示---' + res.result);
            console.log('選擇---' + res.option);
            console.log('click=action---'+res.action);
            if (res.option.indexOf('[]')==0 || res.option == "[]") {
              newcontent = res.text;
            }
            else {
              console.log(res.option.indexOf('"]'))
              console.log(res.option.substring(2, res.option.indexOf('"]')))
              newcontent = res.text,
                newoption = res.option.substring(2, res.option.indexOf('"]')).split('","')
            }
            if (res.action.indexOf('fb_button')!=-1){
              that.setData({
                action: "fb_button",
              })
            }else{
              that.setData({
                action: [],
              })
            }
            msgList.push({
              speaker: 'server',
              contentType: 'text',
              // answer: that.data.text,
              //必須用this.data數據才會拿到
              content: newcontent,
              option: newoption,
              action: that.data.action
            })
            that.setData({
              msgList
            });
            that.setData({
              toView: 'msg-'+(msgList.length - 1)
            });
          })
          console.log(that.data.msgList);
      },

    // adddetial: function () {
    //   wx.navigateTo({
    //     url: '../questionCollection/questionCollection'
    //   })
    // },

    /**
     * 退回上一页
     */
    toBackClick: function () {
      wx.navigateBack({})
    }
})