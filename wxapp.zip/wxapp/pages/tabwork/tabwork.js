// pages/tabwork/tabwork.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pmflag:true,
    pm:"收起",
    adflag:true,
    ad: "收起",
    dormflag:true,
    dorm: "收起",
  },
  changepm(){
    if (this.data.pmflag == true)
    {
      this.setData({
        pmflag: false,
        pm: "展开",
      })
    }
    else
    {
      this.setData({
        pmflag: true,
        pm: "收起",
      })
    }
  },
  changead() {
    if (this.data.adflag == true) {
      this.setData({
        adflag: false,
        ad: "展开",
      })
    }
    else {
      this.setData({
        adflag: true,
        ad: "收起",
      })
    }
  },
  changedorm() {
    if (this.data.dormflag == true) {
      this.setData({
        dormflag: false,
        dorm: "展开",
      })
    }
    else {
      this.setData({
        dormflag: true,
        dorm: "收起",
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  showLeave() {
    wx.navigateTo({
      url: '/pages/leave/leave',
    })
  },
  showOt() {
    wx.navigateTo({
      url: '/pages/overtime/overtime',
    })
  },
  showAtt() {
    wx.navigateTo({
      url: '/pages/except/except',
    })
  },
  showSal() {
    wx.navigateTo({
      url: '/pages/salarySearch/index',
    })
  },
  showRes(){
    wx.navigateTo({
      url: '/pages/resignForm/resignForm',
    })
  },
  showOut() {
    wx.navigateTo({
      url: '/pages/out/out',
    })
  },
  showRs() {
    wx.navigateTo({
      url: '/pages/rs/rs',
    })
  },
  showParty() {
    wx.navigateTo({
      url: '/pages/party/party',
    })
  },
  showAllowance() {
    wx.navigateTo({
      url: '/pages/allowance/allowance',
    })
  },
  showTravel(){
    wx.navigateTo({
      url: '/pages/TravelerStatus/index',
    })
  },
  showRsPlan(){
    wx.navigateTo({
      url: '/pages/rsplan/rsplan',
    })
  },
  showNothing() {
    wx.showModal({
      //  title: '错误信息',
      content: '暂不支持此操作',
      showCancel: false
    });
  },
    /**
       * 生命周期函数--监听页面初次渲染完成
          */
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    Page.onLoad();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})