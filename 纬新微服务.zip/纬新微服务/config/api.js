var NewApiRootUrl = 'https://wkshrms.wistron.com/wks'
//var NewApiRootUrl = 'https://wkshrms.wistron.com/publishguest';
//var NewApiRootUrl = 'http://localhost:37007';
module.exports = {
  Login: NewApiRootUrl + '/login', //账号登录
  LeaveDetail: NewApiRootUrl + '/leave',  //请假
  ResignDetail: NewApiRootUrl + '/resign',  //离职
  //OvertimeSummary: NewApiRootUrl + '/otsummary',  //加班汇总
  Overtime: NewApiRootUrl + '/ot',  //加班
  //OvertimeDetail: NewApiRootUrl + '/otdetail',  //加班明细
  UnattenDetail: NewApiRootUrl + '/unatten',//旷工
  UnbrushDetail: NewApiRootUrl + '/unbrush',//未刷卡
  UnnormalDetail: NewApiRootUrl + '/unnormal',//迟到早退
  Password: NewApiRootUrl + '/password', //修改密码
  VisitorsLogin: NewApiRootUrl + '/GuestFrequency/GuestLogin',
  IntervieweeInfo: NewApiRootUrl + '/GuestFrequency/VisitInfo',
  HistoryVisitors: NewApiRootUrl + '/GuestFrequency/GuestInfo',//历史访客
  SubmitApplication: NewApiRootUrl + '/GuestFrequency/Guest_submit',//提交
  HistoryApplication: NewApiRootUrl + '/GuestFrequency/GuestQuery', //历史申请单
  IsBlackList: NewApiRootUrl + '/GuestFrequency/check_list',
  SalarySearch: NewApiRootUrl + '/Salary',
  OutBase: NewApiRootUrl + '/outbase',//员工进出单基础数据
  OutApply: NewApiRootUrl + '/outapply',//员工进出单送出
  ResignBase: NewApiRootUrl + '/resignbase',//员工离职单基础数据
  ResignApply: NewApiRootUrl + '/resignapply',//员工离职单送出
  SubsidyBase: NewApiRootUrl + '/subsidybase',//技能提報基础数据
  SubsidyApply: NewApiRootUrl + '/subsidyapply',//技能提報送出
  PickQuery:  NewApiRootUrl  +  '/Travel/PickQuery',
  PickDeatil:  NewApiRootUrl  +  '/Travel/PickDeatil',
  DepartQuery:  NewApiRootUrl  +  '/Travel/DepartQuery',
  DepartDeatil:  NewApiRootUrl  +  '/Travel/DepartDeatil',
  PartyDetail: NewApiRootUrl + '/party',
  RsDetail: NewApiRootUrl + '/rs',
  AllowanceDetail: NewApiRootUrl + '/allowance',
  CreatePdf: NewApiRootUrl + '/createpdf',
  RsPlan: NewApiRootUrl + '/rsplan',
  InfoDetail: NewApiRootUrl + '/info',
  ExecutionInit: NewApiRootUrl + '/GuestFrequency/BuildBaseInfo', //初始
  ExecutionHistory: NewApiRootUrl + '/GuestFrequency/BuildInfo',  //历史
  ExecutionSheet: NewApiRootUrl + '/GuestFrequency/BuildAssessInfo',  //评估表
  ExecutionAddWorker: NewApiRootUrl + '/GuestFrequency/ConstructionPersonAdd', //上传施工人员信息
  ExecutionSubmit: NewApiRootUrl + '/GuestFrequency/Build_submit',//提交 
  HistoryApplicationSecond:  NewApiRootUrl  +  '/GuestFrequency/BuildQuery',
  HealthBase: NewApiRootUrl + '/healthbase',
  HealthVisitBase: NewApiRootUrl + '/healthvisitbase',
  HealthForm: NewApiRootUrl + '/healthapply',
  HealthVisitForm: NewApiRootUrl + '/healthvisitapply',
  CertificationBase: NewApiRootUrl + '/certificationbase',
  HealthSearch: NewApiRootUrl + '/healthSearch',
  smartService: NewApiRootUrl + '/chatbot'
};
