// pages/resign/resign.js
var util = require('../../utils/util.js');
var api = require('../../config/api.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    EmpNo: '',
    ChName: '',
    Deptcode: '',
    OndutyLastDay: '',
    ResignationDetailReason: '',
    SignDetailList: [],
    EXT: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中...',
      success: function () {

      }
    });
    this.getDatat();
  },
  getDatat() {
    let that = this;
    util.request(api.ResignDetail, { empno: app.globalData.userInfo,site:app.globalData.site }).then(function (res) {
      if (res.result == "success") {
        that.setData({
          EmpNo: res.FormDetail.EmpNo,
          ChName: res.FormDetail.Chname,
          DeptCode: res.FormDetail.DeptCode,
          OndutyLastDay: res.FormDetail.OndutyLastDay,
          ResignationDetailReason: res.FormDetail.ResignationDetailReason,
          SignDetailList: that.data.SignDetailList.concat(res.SignDetailList),
        });

        wx.hideLoading();
      } else {
        wx.hideLoading();
        wx.showModal({
          content: '暂无离职单记录',
          showCancel: false
        });
               
      }
    });
  },

  enterContact(e) {
    let tel = '051257367888' + ',' + e.target.dataset.ext;  
    wx.makePhoneCall({
      phoneNumber: tel,
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})