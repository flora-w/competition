  //监听input获得焦点

  // pages/contact/contact.js
  var util = require('../../utils/util.js');
  var api = require('../../config/api.js');
  // var api = require('../../config/json.js');
  const app = getApp(); 
  var inputVal = '';
  var data = '';
  // var answer = '';
  // var responseData  = [];
  var msgList = [];
  var windowWidth = wx.getSystemInfoSync().windowWidth;
  var windowHeight = wx.getSystemInfoSync().windowHeight;
  var keyHeight = 0;
  // var localdata = require('../../config/json.js');
  // console.log('000000'+localdata.json);

  //使用本地JSON文件為API
  // var jsonData = require('../../config/json.js');
  

  /**
   * 初始化数据
   */
  function initData(that) {
    //定義頁面加載時就要顯示的數據
    inputVal = '';

    msgList =[
      {
      speaker: 'server',
      contentType: 'text',
      // answer: that.data.text,
      // content: that.data.text,
      // option: that.data.option,
      content: '你好，我是Wistron智能助理-小王，有什麼問題可以試著問我唷!',
      // option: [
      //   'first',
      //   'second',
      //   'third',
      //   'forth'
      // ]
    },
    // {
    //   speaker: 'customer',
    //   contentType: 'text',
    //   content: '哈哈'
    // }
    ]
    that.setData({
      msgList,
      inputVal
    })
  }

/**
 * 计算msg总高度
 */
// function calScrollHeight(that, keyHeight) {
//   var query = wx.createSelectorQuery();
//   query.select('.scrollMsg').boundingClientRect(function(rect) {
//   }).exec();
// }

Page({

    /**
     * 页面的初始数据
     */
    data: {
      msgList: [],
      inputVal: '',
      data: '',
      timestamp: 0,
      option: '',
      scrollHeight: '100vh',
      inputBottom: 0,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      wx.getUserInfo({
        success: function(res) {
          if (res.authSetting['scope.userInfo']) {
            // 已经授权，可以直接调用 getUserInfo 获取头像昵称
            wx.getUserInfo({
              success: function (res) {
                console.log(res.userInfo)
              }
            })
          }
        }
      })

      /*獲取用戶信息 */
      // wx.getUserInfo({
      //   success: function (res) {
      //     console.log(res);
      //     this.data.userInfo = res.userInfo;
      //     this.setData({
      //       userInfo: this.data.userInfo
      //     })
      //   }
      // })

      console.log('options'+options);
      //Date.parse得到的數據單位是毫秒，new Date()得到的數據單位是秒
      var timestamp = Date.parse(new Date());
      console.log("当前时间为：" + timestamp);
      // timestamp = timestamp / 1000;
      // console.log("当前时间戳为：" + timestamp);
      initData(this);
      this.getBaseData();
      this.setData({
        inputVal: inputVal,
        timestamp: timestamp
      });
  },

  /**
       * 发送点击监听
       */
  sendClick: function (e) {
    let that = this;    
    console.log('hihi');

    //先從後台拿到數據，然後存進List裡，再將List渲染到頁面上
    msgList.push({
      speaker: 'customer',
      contentType: 'text',
      content: e.detail.value
    })

    that.setData({
      msgList,
      inputVal,
      data: e.detail.value,
      // timestamp
    });
    console.log('輸入的數據是：' + e.detail.value);

    // util.request(api.smartService, { uid: 'K12893012', timestamp: that.data.timestamp, speak: that.data.data})
    util.request(api.smartService, { uid: app.globalData.userInfo, timestamp: that.data.timestamp, speak: that.data.data })
      .then(function (res) {
        console.log('輸入內容為：' + that.data.data);
        console.log('當前時間戳---' + that.data.timestamp);
        console.log('首回复---' + res.text);
        console.log('首回复顯示---' + res.result);
        console.log('選擇---'+res.option);
        // console.log('身份---'+msgList[0].speaker);
        if (res.option=="[]")
        {
          that.setData({
            content: res.text,
            option: []
          })
        }
        else{
          console.log(res.option.indexOf('"]'))
          console.log(res.option.substring(2,res.option.indexOf('"]')))
          that.setData({
            content: res.text,
            option: res.option.substring(2, res.option.indexOf('"]')).split('","')
          })
        }
        
        msgList.push({
            speaker: 'server',
            contentType: 'text',
            // answer: that.data.text,
            //必須用this.data數據才會拿到
            content: that.data.content,
            option: that.data.option
          })
        that.setData({
          msgList,
        })
      })
    console.log(this.data.msgList);
  },



  getBaseData(e) {
    console.log('我是客服0' + data);
    let that = this;
    console.log('我是客服' + that.data.data);
  },
  // getBaseData() {
  //   let that = this;
  //   // method: POST, 
  //   // util.request(api.smartService, { empno: app.globalData.userInfo, timestamp: app.globalData.timestamp })
  //   util.request(api.smartService, { uid: 'K12893012', timestamp: 1584405318750, speak: 'hi' })
  //     .then(function (res) {
  //       console.log(res.action.text),
  //       console.log(res.action.option)
  //       that.setData({
  //         answer: res.action.text,
  //       })
  //     })
  // },
         

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 获取聚焦
     */
    focus: function (e) {
      keyHeight = e.detail.height;
      this.setData({
        scrollHeight: (windowHeight - keyHeight) + 'px',
      });
      this.setData({
        toView: 'msg-' + (msgList.length - 1),
        inputBottom: keyHeight + 'px'
      })
      //计算msg高度
      // calScrollHeight(this, keyHeight);
    },

    //失去聚焦(软键盘消失)
    blur: function (e) {
      this.setData({
        scrollHeight: '100vh',
        inputBottom: 0
      })
      this.setData({
        toView: 'msg-' + (msgList.length - 1)
      })
    },
    

/* 點擊option使其內容傳輸到input裡 */
  changeValueClick : function(e){
    let that = this;
    var value = e.target.dataset.text;
    console.log(value);
    // inputVal = '';
    
    // console.log(this.data.dataList);
     msgList.push({
        speaker: 'customer',
        contentType: 'text',
        content: value
      })
    that.setData({
      inputVal,
      msgList
    });
    var newcontent ='';
    var newoption = [];
    util.request(api.smartService, { uid: app.globalData.userInfo, timestamp: Date.parse(new Date()), speak:value })
      .then(function (res) {
        console.log('輸入內容為：' + value);
        console.log('首回复---' + res.text);
        console.log('首回复顯示---' + res.result);
        console.log('選擇---' + res.option);
        // console.log('身份---'+msgList[0].speaker);
        if (res.option == "[]") {
          newcontent = res.text;
        }
        else {
          console.log(res.option.indexOf('"]'))
          console.log(res.option.substring(2, res.option.indexOf('"]')))
          newcontent = res.text,
            newoption = res.option.substring(2, res.option.indexOf('"]')).split('","')
        }
        // this.setData({
        //   content: newcontent,
        //   option: newoption
        // })
        msgList.push({
          speaker: 'server',
          contentType: 'text',
          // answer: that.data.text,
          //必須用this.data數據才會拿到
          content: newcontent,
          option: newoption
        })
        that.setData({
          msgList,
        })
      })
    console.log(that.data.msgList);
  },

    // this.setData({
    //   msgList,
    //   inputVal,
    // });
    // inputVal = '';
    // this.setData({
    //   msgList,
    //   inputVal,
    //   responseData,
    //   dataList: jsonData.dataList
    //   // answer
    // });
    // console.log(this.data.dataList);






  adddetial: function () {
    wx.navigateTo({
      url: '../questionCollection/questionCollection'
    })
  },

    /**
     * 退回上一页
     */
    toBackClick: function () {
      wx.navigateBack({})
    }

  })