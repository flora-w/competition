var util = require('../../utils/util.js');
var api = require('../../config/api.js');
var app = getApp();
const { $Toast } = require('../../components/base/index');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index: 0,
    employee: {},//api获取
    objectArray: [],//api获取
    flag: '',
    warn: '',
    applyphone: '',
    applyline: '',
    leader: '',
    lphone: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getBaseData();
  },
  getBaseData() {
    let that = this;
    //util.request(api.SubsidyBase, { empno: app.globalData.userInfo, site: app.globalData.site ,level:'11'})
    util.request(api.SubsidyBase, { empno: 'K19080195', site: 'WKS', level: '11' })
      .then(function (res) {
        if (res.result == "success") {
          that.setData({
            objectArray: that.data.objectArray.concat(res.P37List),
            employee: res.EmpList[0],
            flag: res.flag,
          });
        }
        else if (res.result == "error") {
          wx.showToast({
            image: '../../static/image/err.png',
            title: 'ERROR',
          })
        }
        else {
          that.setData({
            objectArray: that.data.objectArray.concat(res.P37List),
            employee: res.EmpList[0],
            flag: res.flag,
            warn: res.result
          });
          $Toast({
            content: res.result,
            type: 'warning'
          });

        }
        console.log(that.data);
      });
  },
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  getPhone(e) {
    let temp = e.detail.value;
    this.setData({
      applyphone: temp
    })
  },
  getLine(e) {
    let temp = e.detail.value;
    this.setData({
      applyline: temp
    })
  },
  getLeader(e) {
    let temp = e.detail.value;
    this.setData({
      leader: temp
    })
  },
  getLPhone(e) {
    let temp = e.detail.value;
    this.setData({
      lphone: temp
    })
  },
  sendApplication: function () {
    let temp = this.data;
    if (temp.warn != '') {
      $Toast({
        content: temp.warn,
        type: 'warning'
      });
    }
    else {
      var reg = /^[0-9]{4,11}$/;
      if(temp.flag!='success'){
        $Toast({
          content: '暂无技能可申请',
          type: 'warning'
        });
      }
      else if (temp.applyphone == '') {
        $Toast({
          content: '请填写手机号',
          type: 'warning'
        });
      }
      else if (temp.applyline == '') {
        $Toast({
          content: '请填写线别',
          type: 'warning'
        });
      }
      else if (temp.leader == '') {
        $Toast({
          content: '请填写组长姓名',
          type: 'warning'
        });
      }
      else if (temp.lphone == '') {
        $Toast({
          content: '请填写组长联系方式',
          type: 'warning'
        });
      }
      else if (!reg.test(temp.applyphone)) {
        $Toast({
          content: '请填写正确的手机号',
          type: 'warning'
        });
      }
      else if (!reg.test(temp.lphone)) {
        $Toast({
          content: '请填写正确的联系方式',
          type: 'warning'
        });
      }
      else {
        let index = this.data.index;
        let info = { site: 'WKS', applyid: this.data.employee.Empno, applyname: this.data.employee.Chname, applydept: this.data.employee.Deptcode, applyplantid: this.data.employee.PlantID, applyshift: this.data.employee.ShiftName, subsidyid: this.data.objectArray[index].SkillCode, subsidyname: this.data.objectArray[index].SkillName, subsidylevel: this.data.objectArray[index].SkillLevel, applyphone: this.data.applyphone, applyline: this.data.applyline, leader: this.data.leader, leaderphone: this.data.lphone };
        wx.request({
          url: api.SubsidyApply,
          method: 'POST',
          data: info,
          dataType: 'json',
          success(res) {
            wx.hideLoading();
            if (res.data.errno == 401) {
              wx.hideLoading();
              //需要登录后才可以操作
              wx.showModal({
                title: '',
                content: '请先登录',
                success: function (res) {
                  if (res.confirm) {
                    wx.removeStorageSync("userInfo");
                    wx.removeStorageSync("token");

                    wx.navigateTo({
                      url: '/pages/login/login'
                    });
                  }
                }
              });
            }
            else {
            if (res.data.code == 0) {
              $Toast({
                content: res.data.result,
                type: 'warning'
              });
            }
            else {
              wx.showToast({
                title: '提交成功',
              })
              wx.navigateTo({
                url: '/pages/index/index',
              })
              // setTimeout(() => {
              //   wx.switchTab({
              //     //url: '/pages/index/index',
              //     url: '/pages/tabwork/tabwork',
              //   })
              // }, 1000);
            }
            }
          }
        });
      }
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})